# @shakilabs/ui

ShakiLabs 서비스가 공유하는 Vue 3 디자인 primitive 패키지다.

## 목표

- 앱별 브랜드 컬러를 유지하면서 타이포그래피와 기본 UI 동작을 통일한다.
- Tailwind 설정과 무관하게 `00`~`11`에서 같은 컴포넌트를 사용한다.
- 패키지 버전을 고정해 한 앱씩 안전하게 마이그레이션한다.

## 0.2 Angular Editorial 원칙

- 구조 Surface는 1px 경계와 0px 반경을 기본으로 한다.
- Button/Input은 별도 2px 반경을 유지해 카드와 control을 구분한다.
- shadow는 떠 있는 overlay에만 허용한다.
- control은 최소 44px 높이와 2px focus outline을 유지한다.
- 본문은 16px를 유지하고 큰 display 타이포를 절제한다.
- Tailwind, Radix Vue, CVA를 런타임 의존성으로 요구하지 않는다.
- 0.2.4부터 소비 앱의 평면 카드·control·focus 계약도 패키지 CSS 한 곳에서 관리한다.

## 현재 API

- `ShButton`: primary, secondary, ghost, danger
- `ShSurface`: plain, outlined, raised
- `ShSurfaceHeader`, `ShSurfaceBody`, `ShSurfaceFooter`
- `ShText`: display, title, heading, body, caption, label
- `ShSeparator`: horizontal, vertical과 semantic/decorative 모드
- `ShTable`과 Header, Body, Footer, Row, Head, Cell, Caption, Empty
- `ShField`, `ShLabel`, `ShInput`, `ShSelect`, `ShTextarea`, Hint, Error
- `ShBadge`, `ShCallout`, `ShEmptyState`, `ShSkeleton`

## 사용 예시

```ts
import { ShButton, ShSurface, ShText } from "@shakilabs/ui";
import "@shakilabs/ui/styles.css";
```

```vue
<ShSurface padding="lg">
  <ShText as="h2" variant="title">비교 결과</ShText>
  <ShText tone="muted">같은 기준으로 계산한 결과입니다.</ShText>
  <ShButton>자세히 보기</ShButton>
</ShSurface>
```

## 테마 연결

기존 앱의 `--background`, `--foreground`, `--card`, `--primary`, `--border` 토큰을 자동으로 참조한다. 필요한 경우 앱 루트에서 `--sh-*` 값을 직접 덮어쓸 수 있다.

```css
:root {
  --sh-card-radius: 0px;
  --sh-radius-sm: 0.125rem;
  --sh-radius-md: 0.125rem;
  --sh-color-primary: hsl(var(--primary));
}
```

## 데이터와 폼 경계

- Table은 표현과 접근성만 담당하고 정렬, 필터, 페이지네이션은 앱에 둔다.
- Field primitive는 validation 정책과 숫자 변환을 소유하지 않는다.
- Accordion, Dialog, Sheet 같은 focus 관리형 컴포넌트는 별도 패키지 결정을 기다린다.
- 기존 앱의 Header, SEO, 광고, 공유와 도메인 로직은 패키지로 이동하지 않는다.
- 모든 소비 앱은 exact version과 artifact checksum을 사용한다.

## 호환 레이어와 예외

- `.design-system-shell` 아래의 기존 `retro-*` 및 Tailwind surface는 공통 호환 레이어가 같은 시각 계약으로 정규화한다.
- 앱별 `design-system.css`에 공통 규칙을 복제하지 않는다.
- pill은 `data-sh-pill` 또는 `.sh-pill`, 원형은 `data-sh-circle`로 명시한 경우에만 허용한다.
- radio, checkbox, spinner, avatar 이미지, progressbar는 원형 예외에 포함한다.
- Dialog와 AlertDialog만 overlay shadow를 사용할 수 있다.

## 비교 화면

운영 라우트와 분리된 playground에서 기존 장식형 패턴, Table, Form, 상태, 다크 토큰을 비교한다.

```bash
npm run build:playground
npm run preview:playground
```
