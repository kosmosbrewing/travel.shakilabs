# @shakilabs/ui

ShakiLabs 서비스가 공유하는 Vue 3 디자인 primitive 파일럿이다.

## 목표

- 앱별 브랜드 컬러를 유지하면서 타이포그래피와 기본 UI 동작을 통일한다.
- Tailwind 설정과 무관하게 `00`~`11`에서 같은 컴포넌트를 사용한다.
- 패키지 버전을 고정해 한 앱씩 안전하게 마이그레이션한다.

## 현재 API

- `ShButton`: primary, secondary, ghost, danger
- `ShSurface`: plain, outlined, raised
- `ShText`: display, title, heading, body, caption, label

## 사용 예시

```ts
import { ShButton, ShSurface, ShText } from "@shakilabs/ui";
import "@shakilabs/ui/styles.css";
```

```vue
<ShSurface padding="lg">
  <ShText as="h2" variant="title">비교 결과</ShText>
  <ShText tone="muted">같은 기준으로 계산한 결과입니다.</ShText>
  <ShButton>자세히 보기</ShButton>
</ShSurface>
```

## 테마 연결

기존 앱의 `--background`, `--foreground`, `--card`, `--primary`, `--border` 토큰을 자동으로 참조한다. 필요한 경우 앱 루트에서 `--sh-*` 값을 직접 덮어쓸 수 있다.

```css
:root {
  --sh-radius-sm: 0.375rem;
  --sh-radius-md: 0.625rem;
  --sh-color-primary: hsl(var(--primary));
}
```

## 파일럿 제한

- 아직 registry에 publish하지 않는다.
- 앱 Header, Hero, 도메인 카드에는 사용하지 않는다.
- 시각 방향 확정 전 variant를 추가하지 않는다.
- 모든 소비 앱은 exact version을 사용한다.

## 비교 화면

운영 라우트와 분리된 playground에서 기존 장식형 패턴과 공통 primitive를 비교한다.

```bash
npm run build:playground
npm run preview:playground
```
