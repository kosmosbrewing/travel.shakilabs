# @shakilabs/ui

ShakiLabs 서비스가 공유하는 Vue 3 디자인 primitive 패키지다.

> 버전을 올려 12개 앱에 내보낼 때는 [`docs/UI_RELEASE.md`](../../docs/UI_RELEASE.md)의 체크리스트를 따른다.
> 소비 저장소의 `client/vendor/README.md`는 손으로 고치지 않고 `npm run vendor:readme`로 생성한다.

## 목표

- 앱별 브랜드 컬러를 유지하면서 타이포그래피와 기본 UI 동작을 통일한다.
- Tailwind 설정과 무관하게 `00`~`11`에서 같은 컴포넌트를 사용한다.
- 패키지 버전을 고정해 한 앱씩 안전하게 마이그레이션한다.

## Angular Editorial 버전 계약

- 구조 Surface는 1px 경계를 기본으로 하고, 반경은 v3 §2.4 표를 따른다 — 컨테이너 12px(`--sh-panel-radius`) · 카드성 블록 8px(`--sh-card-radius`) · 칩·인풋 4px(`--sh-radius-sm`). 그림자는 여전히 쓰지 않는다(§2.4 shadow.none): 위계는 반경·구분선·여백으로만 만든다.
- Button/Input은 별도 2px 반경을 유지해 카드와 control을 구분한다.
- shadow는 떠 있는 overlay에만 허용한다.
- control은 최소 44px 높이와 2px focus outline을 유지한다.
- 본문은 16px를 유지하고 큰 display 타이포를 절제한다.
- Tailwind, Radix Vue, CVA를 런타임 의존성으로 요구하지 않는다.
- 0.2.5부터 소비 앱의 평면 카드·control·focus 계약도 패키지 CSS 한 곳에서 관리한다.
- 0.2.6부터 반복 결과 배너는 `ShSummaryBanner`의 의미론적 description list를 사용한다.
- 0.2.7부터 desktop 전용 partial radius와 `rounded-md`도 Angular 계약에 포함한다.
- 0.2.8부터 Slider는 대비가 선명한 핸들과 현재 값까지 채워지는 진행 구간을 공통으로 제공한다.
- 0.2.9부터 Slider 아래의 빠른 선택은 `ShPresetGroup`의 동기화된 pill 버튼을 사용한다.
- 0.2.10부터 각진 버튼 호환 규칙에서도 `[data-sh-pill]`의 pill 형태를 보존한다.
- 0.3.4부터 숫자·문자·불리언 입력 프리셋은 같은 고대비 `ShPresetGroup` 칩을 사용한다.
- 0.3.6부터 결과 구성 막대와 한도 진행률은 얇고 각진 트랙, 의미 기반 색상, 명시적 범례를 공유한다.
- 0.3.7부터 프리셋은 44px 터치 영역 안에 32px 시각 칩을 그려 모바일 조작성은 유지하면서 밀도를 높인다.
- 0.3.11부터 차트 막대 rect에는 반경을 두지 않는다. 막대 SVG는 `preserveAspectRatio="none"`이라 viewBox 단위 `rx`가 가로 배율만큼 늘어나 같은 컴포넌트 안에서도 막대 폭에 따라 둥글기가 달라졌다. 반경은 왜곡되지 않는 트랙 CSS(`--sh-radius-sm`, 0.3.30부터 4px)에서만 준다.
- 0.3.12부터 `[role="progressbar"]`는 **알약 예외 셀렉터가 아니다**. a11y 속성을 스타일 훅으로 쓰면 각형이어야 할 막대까지 잡힌다 — 실제로 `ShBulletProgress`의 트랙이 `compatibility.css`의 `!important`에 덮여 12개 앱에서 알약으로 나갔고 0.3.11의 반경 수정이 무효화돼 있었다. 알약은 `[data-sh-pill]`/`.sh-pill`로만 옵트인한다.
- 0.3.12부터 `ShBulletProgress`는 `polarity`(`higher-worse` 기본 · `lower-better`)와 `primary`(`percent` 기본 · `value`)를 받는다. 같은 채움 비율이 화면에 따라 정반대 의미를 가지므로(한도 사용률 vs 회수 시점) 색과 1차 수치를 호출부가 정한다. 기본값은 기존 호출부와 동일하다.
- 0.3.11부터 meter 막대는 값이 전부 0이어도 `aria-valuemax > aria-valuemin`을 보장한다(축이 붕괴하면 상한을 하한+1로 둔다). 값 0의 막대 폭은 그대로 0이다.

## 0.3 Primary Navigation

- `ShPrimaryNavigation`은 탭 한 줄(넘치면 가로 스크롤), 활성 표시와 접근성만 담당한다.
- Vue Router를 직접 의존하지 않고 소비 앱이 `linkComponent`로 `RouterLink`를 주입한다.
- 링크가 아닌 메뉴 동작은 `action` 항목으로 선언해 네이티브 버튼 의미를 유지한다.
- 메뉴 구성, 활성 경로 판정, 서비스 홈 이동과 분석 이벤트는 소비 앱에 둔다.
- 모바일(<48rem)에서 전체 메뉴(☰)가 있으면 탭 줄은 숨는다 — 0.3.38 절 참조. `mobileItems`·`mobileColumns`는 0.3.38부터 무시한다(호환용).
- 탭 줄은 헤더와 같은 틀(`--sh-header-content-width`)에서 첫 탭 글자를 로고 시작선에 맞춘다. 다른 폭은 `--sh-navigation-desktop-max-width`로만 덮는다.

## 현재 API

- `ShButton`: primary, secondary, ghost, danger
- `ShSurface`: plain, outlined, raised
- `ShSurfaceHeader`, `ShSurfaceBody`, `ShSurfaceFooter`
- `ShText`: display, title, heading, body, caption, label
- `ShSeparator`: horizontal, vertical과 semantic/decorative 모드
- `ShTable`과 Header, Body, Footer, Row, Head, Cell, Caption, Empty
- `ShField`, `ShLabel`, `ShInput`, `ShSelect`, `ShTextarea`, Hint, Error
- `ShSlider`: 네이티브 range 의미론, 숫자 v-model, 진행 구간, 키보드·포커스 상태
- `ShPresetGroup`: 선택 상태와 `aria-pressed`, wrap·가로 스크롤을 제공하는 빠른 선택 버튼 그룹
- `ShStepper`: ± 증감 버튼(44px 히트)과 tabular 값 표시, 길게 누름 반복 — 검증·포맷·스텝 정책은 앱 소유
- `ShToggleGroup`: 2~4개 배타 선택 radiogroup, 프리셋 칩 시각 재사용, 화살표 키 순회
- `ShBadge`, `ShCallout`, `ShEmptyState`, `ShSkeleton`
- `ShPrimaryNavigation`: 조용한 탭 한 줄(비활성 muted · 활성 굵기 + accent 밑줄)
- `ShGlobalHeader`: 검정 헤더 — 로고 / 앱 이름 · 사이트 링크 · 유틸 슬롯 · 전체 메뉴(`navItems`가 있을 때)
- `ShBreakdownBar`: 구성 비율, 색 점 범례, 값 formatter, plain·outlined surface
- `ShBulletProgress`: 현재값과 기준 한도의 비율, 끝 기준선·라벨, 초과 상태
- `ShMetricBars`: 지표별 독립 축 비교 막대, positive·signed 도메인, `role="meter"`, `#header` 슬롯
- `ShRankedBars`: 순위 막대. `value: null`(산출 불가)은 폭 0으로 남기고 목록에서 지우지 않는다

### Breakdown 세그먼트 병합 가이드

- ratio 1% 미만 세그먼트는 앱에서 "기타"로 병합해 전달한다 — chartMath는 병합을 계산하지 않는다 (계산은 앱 소유).
- 바에서 세그먼트가 최소 시각폭 4px을 확보하지 못하면 병합 대상으로 본다. 범례 상세가 필요하면 범례에서만 분리 표기한다.

## 사용 예시

```ts
import { ShButton, ShSurface, ShText } from "@shakilabs/ui";
import "@shakilabs/ui/styles.css";
```

```vue
<ShSurface padding="lg">
  <ShText as="h2" variant="title">비교 결과</ShText>
  <ShText tone="muted">같은 기준으로 계산한 결과입니다.</ShText>
  <ShButton>자세히 보기</ShButton>
</ShSurface>
```

```vue
<ShPrimaryNavigation
  :items="navigationItems"
  :active-key="activeItem?.key"
  :link-component="RouterLink"
  @select="trackNavigation"
/>
```

## 테마 연결

기존 앱의 `--background`, `--foreground`, `--card`, `--primary`, `--border` 토큰을 자동으로 참조한다. 필요한 경우 앱 루트에서 `--sh-*` 값을 직접 덮어쓸 수 있다.

```css
:root {
  --sh-card-radius: 0.5rem;
  --sh-panel-radius: 0.75rem;
  --sh-radius-sm: 0.25rem;
  --sh-radius-md: 0.5rem;
  --sh-color-primary: hsl(var(--primary));
}
```

## 데이터와 폼 경계

- Table은 표현과 접근성만 담당하고 정렬, 필터, 페이지네이션은 앱에 둔다.
- Field primitive는 validation 정책과 숫자 변환을 소유하지 않는다.
- Slider는 단일 숫자 입력과 시각 상태만 담당한다.
- PresetGroup은 선택·반응형 표현만 담당하며, 금액·비율 라벨과 프리셋 데이터는 소비 앱에 둔다.
- Accordion, Dialog, Sheet 같은 focus 관리형 컴포넌트는 별도 패키지 결정을 기다린다.
- 기존 앱의 Header, SEO, 광고, 공유와 도메인 로직은 패키지로 이동하지 않는다.
- 모든 소비 앱은 exact version과 artifact checksum을 사용한다.

## 호환 레이어와 예외

- `.design-system-shell` 아래의 기존 `retro-*` 및 Tailwind surface는 공통 호환 레이어가 같은 시각 계약으로 정규화한다.
- 앱별 `design-system.css`에 공통 규칙을 복제하지 않는다.
- pill은 `data-sh-pill` 또는 `.sh-pill`, 원형은 `data-sh-circle`로 명시한 경우에만 허용한다.
- radio, checkbox, slider thumb, spinner, avatar 이미지, progressbar는 원형 예외에 포함한다.
- Dialog와 AlertDialog만 overlay shadow를 사용할 수 있다.

## 비교 화면

운영 라우트와 분리된 playground에서 기존 장식형 패턴, Table, Form, 상태, 다크 토큰을 비교한다.

```bash
npm run build:playground
npm run preview:playground
```

## 0.3.30 — 카드 문법을 v3 §2.4 표로 되돌림

`--sh-card-radius: 0px`·`--sh-radius-*: 2px`의 근거로 CSS 주석이 지목하던 "각형 규약(ADR-002)"은
`docs/decisions/`에 **존재하지 않는 문서**다(002번은 Drizzle 채택건). 문서화되지 않은 값이 v3 §2.4
표(sm 4 · md 8 · lg 12)를 덮고 있었으므로 표를 정본으로 되돌렸다.

- 컨테이너(`.retro-panel`·`.retro-details`·`.retro-board-list`·`.retro-chart`·`.seo-rich-guide`)는
  `--sh-panel-radius`(12px), 그 안의 블록은 `--sh-card-radius`(8px). 바깥이 한 단계 크다.
- **카드 안 카드 금지**: `.retro-panel`/`.retro-details` 안에 중첩된 `.retro-panel-muted`·`.retro-stat`은
  테두리를 잃고 면으로만 구분된다(라이브 중첩 149곳: finance 25 · card 63 · invest 37 · loan 24).
  홀로 놓인 muted 패널은 테두리를 유지한다 — 캔버스 위에서 경계를 잃으면 안 되기 때문이다.
- `.retro-panel-content`·`.retro-titlebar` 패딩을 대칭(16/20px)으로. 앱 `@apply`는 (0,1,0)이라
  패키지 (0,2,0) 선언이 이긴다.
- **그림자는 넣지 않는다.** AWS 콘솔식 elevation을 따라가면 Archive 톤의 평평함이 사라진다.
  `box-shadow: none !important`는 그대로다.

## 0.3.35 — 본문 프레임을 하나로 (사용자 결정 2026-09-24)

v3 §2.7의 컨테이너 3역할(page 64rem · tool 72rem · prose 42rem)을 **폐지**했다.
역할별 폭을 가운데 정렬로 구현한 결과, 화면을 이동할 때마다 제목 시작 x가
**7가지(168·232·253·257·408·424·429px)**로 흩어졌다(라이브 23화면 실측, 1440px).
0.3.34는 홈에서 헤더까지 1024로 줄여 헤더 폭도 두 가지가 됐다.

- 모든 `.sh-container`는 **`--sh-container-frame`(72rem)** 하나를 쓴다. 헤더·2차 내비도 같다.
- `--tool`/`--page`/`--prose` 클래스와 `--sh-container-*` 토큰은 **마크업 호환용 별칭**이다.
  값은 전부 프레임이다 — 역할별로 다시 벌리면 계약 테스트가 막는다.
- 읽는 폭은 프레임을 좁히지 않고 **글줄만** 묶는다: `.sh-container--prose` 안의
  `h1~h4·p·ul·ol·dl·blockquote`에 `--sh-text-measure`(42rem). 가운데로 옮기지 않으니
  제목·본문이 로고와 같은 x에서 시작한다. 표는 묶지 않는다(스크롤 래퍼가 처리).
- 헤더 기준선(`--sh-header-content-width`)은 프레임에 고정. 페이지 내용으로 바꾸는
  `:has()` 규칙은 어느 스타일 파일에도 두지 않는다(전수 검사).

카드 안에 든 제목은 카드 패딩(20~24px)만큼 안쪽에서 시작하는 게 정상이다 — 정렬은
**카드 테두리(박스)**로 판정한다, 글자로 하지 않는다.

## 0.3.36 — `ShGapBars`: 1위 대비 차이 막대

seller "월 판매 손익 그래프"는 순이익 8,537,400 / 8,025,300 / 7,800,300원을 0부터 그려
**네 막대가 같은 길이로 보였다**(실제 차이 6~9%). 축을 잘라 차이를 키우면 막대 길이가 거짓말을 한다.
그래서 총액은 숫자로 두고, **1위와의 차이 자체를 0 기준선부터** 그리는 차트를 추가했다.

```vue
<ShGapBars
  title="월 순이익 — 1위와의 차이"
  :items="[{ key: 'smartstore', label: '스마트스토어', value: 8537400 }, …]"
  :format-value="formatWon"
  better="higher"
/>
```

- `better`: `"higher"`(순이익·환급액) 또는 `"lower"`(수수료·이자·비용). 1위 판정과 부호가 여기서 정해진다.
- 1위 행은 막대 없이 기준선 옆에 `기준`, 나머지는 **가장 큰 차이 대비 길이**의 회색 막대 + `−512,100원 −6.0%`.
- 동률은 같은 순위(경쟁 순위 1·1·3), 1위 동률은 `공동 1위`. `value: null`은 순위 밖으로 끝에 `산출 불가`.
- 강조는 하나: 1위 배지·기준선만 `highlightTone`, 막대는 회색, 글자는 텍스트 토큰만.
- 막대는 장식(`aria-hidden`), 보조기기는 `1위 대비 −512,100원 −6.0%` 텍스트를 읽는다.
- 1위 값이 0 이하이면 %를 적지 않는다(손실 기준의 %는 부호 뜻이 뒤집힌다). 0.0%로 반올림되는 차이는 `0.1% 미만`.
- 계산은 `gapsToBest(values, better)` 한 곳 — 앱이 같은 수치를 쓸 때 복사하지 말고 import한다.

## 0.3.38 — 순수 내비게이션 (사용자 결정 2026-09-25)

내비는 "어디에 있나 · 어디로 갈 수 있나"만 답한다. 정보(팁 문장)·전환기·분류 묶음은 두지 않는다.

- 헤더: `로고 / 앱 이름` · 블로그·소개 · 테마 · ☰(모바일). 앱 이름은 `app` prop으로 services.json의 `shortLabel`을 쓰고(푸터와 같은 이름), 링크는 그 `href`(끝 슬래시 없음)로 간다 — RouterLink "/"는 "/앱/"이 되어 308을 거친다. `tip` prop·`#tip` 슬롯은 더 이상 그리지 않는다.
- 탭: 비활성 `--sh-color-muted`/500, 활성 `--sh-color-text`/600 + 2px `--sh-color-accent` 밑줄. 앱 강조색은 밑줄에만 쓴다. "전체 계산기" 같은 허브 입구는 앱이 `items` 마지막에 넣는다.
- 모바일: 고정 영역은 헤더 56px뿐 — 탭 줄은 ☰가 있으면 숨는다. ☰ 패널은 오른쪽에서 열리고 같은 목록 + 사이트 링크만 싣는다. 링크는 닫혀 있어도 DOM에 있다(크롤 경로).
- 테마 토글: `ShThemeToggle` 하나로 — ☰와 같은 44px 정사각·테두리 없음·선 아이콘. 동작(.dark·color-scheme·저장)도 패키지가 하고, 앱은 첫 페인트 스크립트와 같은 `storage-key`만 준다.
- 삭제: `--sh-nav-active-wash` 토큰(쓰는 곳이 없다), compatibility.css의 `.design-system-theme-toggle` 훅. 앱이 덮어 둔 값·옛 탭 클래스(`__link--mobile`·`__indicator` 등) 오버라이드는 지운다.

```vue
<ShGlobalHeader app="finance" :links="links" :link-component="RouterLink"
  :nav-items="PRIMARY_NAV_ITEMS" :nav-active-key="activeKey">
  <template #utility><ShThemeToggle storage-key="salary-calc:theme:v1" /></template>
</ShGlobalHeader>
<ShPrimaryNavigation :items="PRIMARY_NAV_ITEMS" :active-key="activeKey" :link-component="RouterLink" />
```

## 0.3.39 — 폼 칸 속성은 실제 칸에

`ShSelect`(항상)와 접미사 달린 `ShInput`은 칸을 `span`으로 감싼다. 0.3.38까지는 앱이 준 속성이 그 겉 `span`에
떨어져서 `<label for>`가 칸에 닿지 않고(접근 이름 없음), `inputmode`·`min`·`max`·`step`이 무시돼 모바일 숫자 키패드가
뜨지 않고, `aria-label`·`disabled`도 헛돌았다(loan 상환 계산기·nutri 필터 실측).

- 자동 상속을 끄고 `class`·`style`만 겉에(앱 레이아웃 클래스는 그대로), 나머지(id·aria-*·inputmode·name·disabled·이벤트)는 실제 `input`/`select`에.
- 접미사 없는 `ShInput`은 원래 칸이 루트라 동작이 같다.
- `verify-dist`가 빌드된 dist를 렌더해 속성 위치를 확인한다(소스 정규식이 아니라 결과 마크업으로).

## 0.3.43 — 허브 제목 한 척도 + 글자 13px 하한 (사용자 결정 2026-10-04)

- `ShText variant="display"` = **허브 제목 토큰**: GmarketSans 700, 28px(640px 미만 24px), 줄간격 1.25. 옛 값은 Pretendard
  `clamp(30px, 4vw, 44px)`라 허브 5곳(root·card·car·invest·travel)이 도구 화면 h1(20px)과 두 배 넘게 달랐다(디자인 점검 v8).
  display는 탐색이 주목적인 화면(앱 홈 허브·전체 도구) h1에만 쓴다 — 도구·내용 화면 h1은 앱의 20px 표준 그대로.
  브랜드 글꼴로 바뀌므로 소비 앱은 **`fonts:subset`을 다시 돌려** 허브 제목 글자를 서브셋에 넣어야 한다(렌더 수집기는 계산된 글꼴로 줍는다).
- 패키지가 그리는 글자는 **전부 13px 이상**(라벨·배지·표 머리·표 스크롤 안내·요약 눈썹·결과 라벨·푸터·드로어·모바일 헤더 링크·차트 범례·막대 값·설명).
  **예외는 차트 축 눈금 `__scale` 12px 하나**(`.sh-bullet__scale`·`.sh-metric-bars__scale`). 계약 테스트가 미디어 쿼리 안까지 선언을 읽어 강제한다.

## 0.3.42 — 차트 SVG `<title>` 제거

`ShBreakdownBar` 구획(rect)의 SVG `<title>`을 `role="img"` + `aria-label`로 바꾼다. 네이버 서치어드바이저가 SVG `<title>`을
문서 `<title>` 중복으로 세어 사이트 진단에 "title 요소 2개 이상" 61페이지가 떴다(2026-10-01). 읽기 보조는 범례(dl)와 aria-label이
그대로 맡는다. 계약 테스트가 차트 컴포넌트 5종 전체에서 SVG `<title>`을 금지한다.

## 0.3.41 — `ShMemoryControl`: "복원함"은 앱이 확인할 때만

초안을 찾은 순간 "이 탭 입력을 복원함"이라고 말하던 것을 고친다. 앱은 링크·공유 URL 값을 지키려고 복원을
건너뛰거나(변형 경로·쿼리로 들어온 경우), 검증에 실패한 초안을 `clear()`로 버린다 — 두 경우 모두 아무것도
복원되지 않았는데 스위치는 복원했다고 말했다.

- 초안을 찾으면 스위치는 "이 탭에 입력 기억 중"(켜짐)으로 두고 `restore`를 보낸다.
- 앱이 초안을 실제로 화면에 되살렸으면 `markRestored()`를 부른다 — 이때만 "이 탭 입력을 복원함".
- `clear()`는 초안을 지우고 스위치도 끈다(앱이 거부한 뒤 저장을 멈추므로).

```ts
function handleRestore(payload: unknown) {
  const parsed = schema.safeParse(payload);
  if (!parsed.success) return control.value?.clear();
  if (!enteredBare) return; // 링크 값 유지 — 스위치는 "기억 중"
  control.value?.markRestored();
  router.replace(parsed.data.path);
}
```

## 0.3.40 — `ShNextActions`: 다음 계산

결과 뒤에 이어서 볼 계산 2~4개. 앱마다 따로 만든 블록 7개(카드 5단 글·CTA 문구 4종·글자 크기 제각각)를 한 문법으로.

```vue
<ShNextActions
  :items="[{ key: 'regional', title: '퇴사하면 건보료가 얼마가 되나', to: '/regional-health',
             value: '약 22,379원', note: '지역가입 · 재산·자동차 없을 때 하한액' }]"
  :link-component="RouterLink"
  @select="(item) => trackNext(item)"
/>
```

- 카드 전체가 링크. 제목 한 줄 + (있으면) 미리 계산 값(강조색)과 짧은 조건 한 줄. 설명 문장·"계산하러 가기" 줄은 두지 않는다 — 도착한 계산기가 말한다.
- 제목 기본값 "이어서 계산하기", 소개 문단 없음.
- 놓인 폭을 스스로 본다(container query): 반폭 칸이면 목록(값이 오른쪽 끝), 44rem 이상이면 3열.
- 미리 계산 값에는 조건을 꼭 붙인다(하한액·기준 가정) — 값만 두면 약속처럼 읽힌다.
